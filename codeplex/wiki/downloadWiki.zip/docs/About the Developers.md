**Manitcor**
Professional software developer with close to 15 years of experience in large data systems design, development and deployment. Likes writing code even more than playing KSP. 

**Want to be a developer on KerbalData?**
Right now I am not actively looking for assistance but will always entertain offers for help, please contact me @ manitcor@gmail.com to discuss your ideas. 


