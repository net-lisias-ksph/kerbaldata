[How does KerbalData save me time?](Time-Savings)

# API Documentation
* 0.3.1 Alpha Documentation [Web](http://manitcor.com/ksp/KerbalData/0.3.1Alpha/index.php) | [CHM](http://manitcor.com/ksp/KerbalData/0.3.1Alpha/KerbalDataApiReference.chm)
* 0.3.0 Alpha Documentation [Web](http://manitcor.com/ksp/KerbalData/0.3.0Alpha/index.php) | [CHM](http://manitcor.com/ksp/KerbalData/0.3.0Alpha/KerbalDataApiReference.chm)
* [0.2.0 Alpha Documentation](0.2.0-Alpha-Documentation) 
* [0.1.5 Alpha Documentation](0.1.5-Alpha-Documentation)


# Design/Developer Guide
* [Architecture Overview](Architecture-Overview)

[About the Developers](About-the-Developers)