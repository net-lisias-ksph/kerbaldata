The core idea behind KerbalData is to allow developers the freedom to make their ideas real without struggling with day to day data management concerns. Focus and time can be placed on what is done with the data rather than how to store the data. 

The developer of [PayLoader](url_http___kerbalspaceport.com_payloader_) writes some pretty decent code that was easy to follow, it also made a prime example of how KerbalData can help a developer. While there are differences between the Java and .NET platforms the syntax and readability issues are nearly identical. 

PayLoader uses a fast scan method to parse through a file and find data. This is fast and somewhat easy to write but can become complex and fragile very quickly. Further you have to mix parsing needs with your business needs of setting values making the code harder to read. Without an API, this is one option many developers take. 

{code:java}
int line = 0; 
String tmp = "";
String[]() pos = new String[3](3);
String pref = "    pos = ";
String pref2 = "pos ="; 

String target; 

BigDecimal Ypos = new BigDecimal(0); 

BigDecimal XposPay = new BigDecimal(0); 
BigDecimal ZposPay = new BigDecimal(0);
BigDecimal XposLau = new BigDecimal(0); 
BigDecimal ZposLau = new BigDecimal(0);

BigDecimal Yoff = new BigDecimal(spacer); 

BigDecimal XoffPay = new BigDecimal(0); 
BigDecimal ZoffPay = new BigDecimal(0);
BigDecimal XoffLau = new BigDecimal(0);
BigDecimal ZoffLau = new BigDecimal(0);

target = pref2;

for(line = 0;line<launcher.datalist.size()-1;line++) 
{
tmp=launcher.readString(line); 

if (tmp.contains(target))
{
  XposLau = 
	new BigDecimal(tmp.substring(tmp.lastIndexOf('=')+2,tmp.indexOf(','))); 
  Ypos = 
	 new BigDecimal(tmp.substring(tmp.indexOf(',')+1,tmp.lastIndexOf(',')));
  ZposLau = 
	 new BigDecimal(tmp.substring(tmp.lastIndexOf(',')+1,tmp.length())); 
  
  if(centreOrigin == 'V') 
  {
	XoffLau=XposLau; 
	ZoffLau=ZposLau; 
  }
  else if(centreOrigin == 'P') /
  {
	for(line = 0;line<payload.datalist.size()-1;line++) 
	{
	  tmp=payload.readString(line); 
	  if (tmp.contains(target)) 
	  {
		XposPay = 
		  new BigDecimal(tmp.substring(tmp.lastIndexOf('=')+2,tmp.indexOf(',')));
		ZposPay = 
		  new BigDecimal(tmp.substring(tmp.lastIndexOf(',')+1,tmp.length())); 
		break;
	  }
	}
	
	XoffLau=XposPay.subtract(XposLau); 

	XoffLau=XoffLau.negate(); 
	ZoffLau=ZposPay.subtract(ZposLau); 
	ZoffLau=ZoffLau.negate(); 
  }
  else if(centreOrigin == 'L') 
  {
	XoffLau=new BigDecimal(0); 
	ZoffLau=new BigDecimal(0);
  }
  else 
  {
	XoffLau=XposLau; 
					 
	ZoffLau=ZposLau; 
  }
  Yoff=Yoff.add(Ypos); 
  
  break;
}

// This code continues looping through the file reader 
// making multiple operations to handle the task
// of centering the craft correctly. 
{code:java}

Next we have similar code using the KerbalData API. Because the data is already parsed and loaded into an object structure the developer has the freedom to skip any parsing concerns and focus only on the feature at hand. 

The difference in loading strategy in this case, for a tool like payloader may actually make it so payloader is faster than using KerbalData API however for end users the hit should be minor. 
{code:c#}
var orgin = CenterOrgin.Vab;

var kd = new KerbalData(@"C:\myksp\install\location");
var launcher = kd.CraftInVab["mylauncher"](_mylauncher_);
var payload = kd.CraftInVab["mypayload"](_mypayload_);

decimal ypos;
decimal xposPay, zposPay, xposLau, zposLau;
decimal yoff;
decimal xoffPay, zoffPay, xoffLau, zoffLau;

var launcherPart = launcher.Parts[0](0);
var launcherPos = launcherPart["pos"](_pos_).Select(p => decimal.Parse(p.ToString())).ToArray();

xposLau = launcherPos[0](0);
ypos = launcherPos[1](1);
zposLau = launcherPos[2](2);

switch (orgin)
{
	case CenterOrgin.Vab:
		xoffLau = xposLau;
		zoffLau = zposLau;
		break;
	case CenterOrgin.Payload:
		var payloadPart = payload.Parts[0](0);
		var payloadPos = 
                  payloadPart["pos"](_pos_).Select(p => decimal.Parse(p.ToString()));
		
		xposPay = payloadPos[0](0);
                zposPay = payloadPos[1](1);
                xoffLau = (xposPay - xposLau) * -1; 
                zoffLau = (zposPay - zposLau) * -1; 
		break;
	case CenterOrgin.Launcher:
		xoffLau = 0;
		zoffLau = 0;	
		break;
	default:
		xoffLau = xposLau;
		zoffLau = zposLau;	
		break;
}

yoff= yoff + ypos;

// Here would be the rest of the method to match Java, the rest of the method
// is very similar to this small sample running operations on various fields and
// calculating new values based on context. 
{code:c#}

The above C# code was transposed in about 10mins (not including time to read/understand the code). It would not have taken much longer to do it from scratch if you knew what steps and calculations you wanted ahead of time.  

Finally, when using KerbalData you have some additional protection against game upgrades from breaking your software. In many cases you won't have to do anything, the parsing system is designed to be very flexible to minor changes in the file format (and this will improve over time) while with larger changes KerbalData aims to keep developer impact minimal to at most (hopefully) just updating the KerbalData serialization binaries. Further even when code changes are done, due to simplified usage syntax grep tools are more effective in finding and updating code in bulk. 